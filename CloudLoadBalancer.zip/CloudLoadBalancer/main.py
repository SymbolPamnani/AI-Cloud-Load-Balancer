from load_balancer import LoadBalancer
from graphs import (
    show_comparison_graph,
    show_response_time_graph
)

lb = LoadBalancer()

print("\nDistributing Tasks...")
lb.distribute_tasks()

print("\nChecking Auto Scaling...")
lb.auto_scale()

print("\nBefore Balancing:")
lb.show_status()

before_loads = lb.get_server_loads()

print("\nBalancing Load...")
lb.balance_load()

print("\nChecking Fault Tolerance...")
lb.fault_tolerance()

print("\nAfter Balancing:")
lb.show_status()

after_loads = lb.get_server_loads()

response_times = lb.get_response_times()

names = lb.get_server_names()

show_comparison_graph(
    names,
    before_loads,
    after_loads
)

show_response_time_graph(
    names,
    response_times
)