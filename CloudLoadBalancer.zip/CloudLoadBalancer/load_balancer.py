from server import Server
import random

class LoadBalancer:
    def __init__(self):
        self.servers = [
            Server("Server 1"),
            Server("Server 2"),
            Server("Server 3")
        ]

    def distribute_tasks(self):
        for _ in range(20):

            task = random.randint(10, 25)

            lowest_server = min(self.servers, key=lambda s: s.load)

            lowest_server.add_task(task)

    def auto_scale(self):

        high_load_servers = [s for s in self.servers if s.load > 80]

        if len(high_load_servers) == len(self.servers):

            new_server = Server(f"Server {len(self.servers)+1}")

            self.servers.append(new_server)

            print("\nAUTO SCALING ACTIVATED")
            print(f"{new_server.name} created successfully!")

    def balance_load(self):

        overloaded = [s for s in self.servers if s.load > 70]

        underloaded = [s for s in self.servers if s.load < 50]

        for over in overloaded:

            if underloaded:

                target = min(underloaded, key=lambda s: s.load)

                transfer = 20

                over.reduce_load(transfer)

                target.add_task(transfer)

                print(f"\nLoad shifted from {over.name} to {target.name}")

    def fault_tolerance(self):

        failed_servers = [s for s in self.servers if s.load > 95]

        for failed in failed_servers:

            backup = min(self.servers, key=lambda s: s.load)

            if backup != failed:

                backup.add_task(30)

                failed.reduce_load(30)

                print(f"\nFAULT DETECTED in {failed.name}")
                print(f"Backup activated on {backup.name}")

    def show_status(self):

        print("\n--- SERVER STATUS ---")

        for server in self.servers:

            print(
                f"{server.name}: "
                f"Load = {server.load}% | "
                f"Response Time = {server.response_time} sec"
            )

    def get_server_loads(self):

        return [server.load for server in self.servers]

    def get_response_times(self):

        return [server.response_time for server in self.servers]

    def get_server_names(self):

        return [server.name for server in self.servers]