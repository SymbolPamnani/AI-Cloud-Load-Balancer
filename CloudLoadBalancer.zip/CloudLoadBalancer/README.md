# AI-Based Intelligent Cloud Load Balancer

## Project Overview
This project simulates a cloud computing environment where tasks are distributed among multiple servers using intelligent load balancing techniques.

The system automatically:
- Detects overloaded servers
- Shifts traffic to low-load servers
- Creates new servers using auto scaling
- Activates backup servers during failures
- Analyzes response time and server efficiency

---

## Features
- AI-based Load Balancing
- Auto Scaling
- Fault Tolerance
- Response Time Analysis
- Graph Visualization
- Cloud Server Simulation

---

## Technologies Used
- Python
- matplotlib
- numpy
- VS Code

---

## How to Run

### Install Libraries

```bash
pip install matplotlib numpy


# To Run Project
python main.py

Project Structure
CloudLoadBalancer/
│
├── main.py
├── server.py
├── load_balancer.py
├── graphs.py
├── README.md
└── screenshots/


--------Output----------

The project generates:

Server load balancing simulation
Before vs After comparison graphs
Response time analysis graphs
Future Improvements
Machine learning prediction
Real cloud integration
Web dashboard
Docker deployment