import matplotlib.pyplot as plt
import numpy as np

def show_comparison_graph(server_names, before, after):

    x = np.arange(len(server_names))
    width = 0.35

    fig, ax = plt.subplots()

    ax.bar(x - width/2, before, width, label='Before Balancing')
    ax.bar(x + width/2, after, width, label='After Balancing')

    ax.set_xlabel('Servers')
    ax.set_ylabel('CPU Load (%)')
    ax.set_title('AI Load Balancing Comparison')

    ax.set_xticks(x)
    ax.set_xticklabels(server_names)

    ax.legend()

    plt.show()

def show_response_time_graph(server_names, response_times):

    plt.figure()

    plt.plot(server_names, response_times, marker='o')

    plt.xlabel('Servers')
    plt.ylabel('Response Time (sec)')
    plt.title('Server Response Time Analysis')

    plt.show()