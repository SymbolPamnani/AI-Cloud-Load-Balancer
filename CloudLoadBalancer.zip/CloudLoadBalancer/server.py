import random

class Server:
    def __init__(self, name):
        self.name = name
        self.load = 0
        self.response_time = random.randint(1, 5)

    def add_task(self, task_load):
        self.load += task_load

        self.response_time = round(self.load / 20, 2)

    def reduce_load(self, amount):
        self.load -= amount

        self.response_time = round(self.load / 20, 2)

    def get_load(self):
        return self.load

    def get_response_time(self):
        return self.response_time